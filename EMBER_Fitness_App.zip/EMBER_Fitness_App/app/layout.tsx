import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EMBER | Your fitness, in focus",
  description: "A personal weekly nutrition, training and hydration journal.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
